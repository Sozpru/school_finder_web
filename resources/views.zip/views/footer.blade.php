<!-- ======= Footer ======= -->

<footer id="footer" class="footer">
    <div class="container">
        <div class="copyright">
            &copy; Copyright <strong></strong>. All Rights Reserved
        </div>
        
    </div>
</footer>